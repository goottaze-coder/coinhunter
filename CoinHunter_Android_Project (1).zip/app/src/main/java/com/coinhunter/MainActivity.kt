package com.coinhunter

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply {
            text = "🪙 Coin Hunter\n\nنسخه آزمایشی کنترل حرکت"
            textSize = 23f
            gravity = Gravity.CENTER
        }
        val enable = Button(this).apply {
            text = "فعال‌کردن دسترسی کنترل حرکت"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val note = TextView(this).apply {
            text = "\nپس از فعال‌سازی سرویس، بازی را باز کنید. این نسخه فقط موتور اجرای حرکت را آزمایش می‌کند؛ تشخیص خودکار سکه و مانع هنوز به ماژول بینایی نیاز دارد."
            textSize = 15f
        }
        layout.addView(title); layout.addView(enable); layout.addView(note)
        setContentView(layout)
    }
}
