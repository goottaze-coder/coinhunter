package com.coinhunter

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class GameControlService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // These gestures are the game's controls: left/right, up to jump, down to slide.
    fun swipe(direction: Direction, durationMs: Long = 180L) {
        val w = resources.displayMetrics.widthPixels.toFloat()
        val h = resources.displayMetrics.heightPixels.toFloat()
        val cx = w * 0.5f
        val cy = h * 0.72f
        val distance = w * 0.22f
        val path = Path().apply {
            moveTo(cx, cy)
            when (direction) {
                Direction.LEFT -> lineTo(cx - distance, cy)
                Direction.RIGHT -> lineTo(cx + distance, cy)
                Direction.JUMP -> lineTo(cx, cy - h * 0.18f)
                Direction.SLIDE -> lineTo(cx, cy + h * 0.18f)
            }
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    enum class Direction { LEFT, RIGHT, JUMP, SLIDE }
}
